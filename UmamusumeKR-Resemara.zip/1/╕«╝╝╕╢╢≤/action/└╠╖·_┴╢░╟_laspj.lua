-- ��� Ÿ�
if motion and tazuna then
 SendKakaoTalk(0, "", true)
 Stop()
end